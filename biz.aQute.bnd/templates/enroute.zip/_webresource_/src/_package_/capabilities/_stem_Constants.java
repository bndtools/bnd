package _package_.capabilities;

/**
 * _project_
 */
public interface _stem_Constants {
	/**
	 * 
	 */
	String _STEM_PATH="/_packagepath_";
	/**
	 * 
	 */
	String _STEM_VERSION="1.0.0";
}
