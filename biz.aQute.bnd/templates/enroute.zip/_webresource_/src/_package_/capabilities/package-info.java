@org.osgi.annotation.versioning.Version(_stem_Constants._STEM_VERSION)
package _package_.capabilities;
