package _package_.provider;

import org.junit.Test;

import _package_.api._stem_;

/*
 * Example JUNit test case
 * 
 */

public class _stem_ImplTest {

	/*
	 * Example test method
	 */

	@Test
	public void simple() {
		_stem_ impl = new _stem_Impl();
		
		impl.say("Hello World");
	}

}
