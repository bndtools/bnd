package _package_;

/**
 * 
 */
public interface _stem_ {
	
	/**
	 * 
	 */
	
}
