@org.osgi.annotation.versioning.Version("1.0.0")
package _package_;
