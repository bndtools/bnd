package _package_;

import org.osgi.service.component.annotations.Component;

/**
 * 
 */
@Component(name = "_pid_")
public class _stem_Impl {

}
