package _package_.provider;


import org.osgi.service.component.annotations.Component;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * 
 * 
 * 
 * 
 */
@Component(name="_pid_")
public class _stem_Impl {
	final static Logger log = LoggerFactory.getLogger(_stem_Impl.class);

	/*
	 * 
	 * 
	 * 
	 * 
	 */
}
